package org.nlogo.extensions.time.datatypes

class TimeSeriesRecord(var time: LogoTime, var dataIndex: Int)
